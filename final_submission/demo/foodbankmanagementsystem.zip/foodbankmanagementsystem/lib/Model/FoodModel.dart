import 'package:flutter/cupertino.dart';

class FoodModel{
  String name;
  String category;
  TextEditingController quantity;

  FoodModel({required this. name,required this.category, required this.quantity});
  Map<String, dynamic> toMapWithoutController() {
    return {
      'name': name,
      'category': category,
     'quantity':int.parse(quantity.text)
    };
  }
}