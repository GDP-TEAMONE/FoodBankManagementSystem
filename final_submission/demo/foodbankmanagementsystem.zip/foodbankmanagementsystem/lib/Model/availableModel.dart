class AvailableModel{
  DateTime start, end;
  String uid, id;

  AvailableModel({required this.id, required this.start, required this.end, required this.uid});
}