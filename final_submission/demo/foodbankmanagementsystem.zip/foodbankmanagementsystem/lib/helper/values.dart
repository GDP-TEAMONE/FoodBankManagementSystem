const category = [
  'Fruits',
  'Vegetables',
  'Dairy Products',
  'Grains',
  'Protein Foods',
  'Canned Goods',
  'Beverages',
  'Snacks',
  'Bakery Items',
  'Frozen Foods',
  'Prepared Meals',
  'Condiments',
  'Baby Food',
  'Pet Food',
];

const subcategory = [
  [
    'Apples',
    'Bananas',
    'Oranges',
    'Berries (strawberries, blueberries, etc.)',
    'Citrus (lemons, limes, etc.)',
    'Tropical Fruits (pineapple, mango, etc.),'
  ],
  [
    'Leafy Greens (lettuce, spinach, kale)',
    'Root Vegetables (carrots, potatoes, onions)',
    'Cruciferous Vegetables (broccoli, cauliflower, cabbage)',
    'Nightshade Vegetables (tomatoes, peppers, eggplant)',
    'Legumes (beans, peas, lentils)',
  ],
  [
    'Milk',
    'Cheese',
    'Yogurt',
    'Butter',
    'Eggs',
  ],[
    'Rice',
    'Pasta',
    'Bread',
    'Cereal',
    'Flour',
  ],[
    'Meat (beef, chicken, pork)',
    'Fish',
    'Tofu',
    'Beans',
    'Nuts',
  ],[
    'Soup',
    'Vegetables',
    'Fruits',
    'Beans',
    'Fish',
  ],[
    'Water',
    'Juice',
    'Soda',
    'Tea',
    'Coffee',
  ],[
    'Chips',
    'Crackers',
    'Popcorn',
    'Nuts',
    'Granola Bars',
  ],[
    'Bread',
    'Pastries',
    'Bagels',
    'Muffins',
    'Cookies',
  ],[
    'Frozen Vegetables',
    'Frozen Fruit',
    'Frozen Meals',
    'Ice Cream',
    'Frozen Pizza',
  ],[
    'Ready-to-Eat Meals',
    'Microwaveable Meals',
    'Deli Items',
  ],[
    'Ketchup',
    'Mustard',
    'Mayonnaise',
    'Salad Dressing',
    'Salsa',
  ],[
    'Infant Formula',
    'Baby Cereal',
    'Baby Puree Jars',
    'Baby Snacks',
    'Toddler Meals',
  ],[
    'Dog Food',
    'Cat Food',
    'Pet Treats',
    'Pet Supplements',
  ]
];
