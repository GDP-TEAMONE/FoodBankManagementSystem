
const homePageRoute = "/dashboard";
const authenticationPageRoute = '/login';
const registerPageRoute = '/register';
const profilePageRoute = '/profile';
const fooddonorhomePageRoute = '/fooddonorhome';
const volunteerhomePageRoute = '/volunteerhome';
const recipienthomePageRoute = '/recipienthome';
const donationsPageRoute = '/donationsPageRoute';
const aboutusPageRoute = '/aboutusPageRoute';

