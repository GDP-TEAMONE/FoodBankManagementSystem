import 'dart:ui';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import '../../Model/User.dart';
import '../../helper/auth_service.dart';
import '../../route.dart';
import '../Widgets/Appbar.dart';
import '../Widgets/ChatInputField.dart';
import '../Widgets/chat_box.dart';

class RecipientHome extends StatefulWidget {
  @override
  State<RecipientHome> createState() => _RecipientHomeState();
}

class _RecipientHomeState extends State<RecipientHome> {
  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/bg.png"), fit: BoxFit.fill)),
        child: Stack(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Appbarr(ishome: true,),
                Container(
                  color: Colors.white,
                  height: 10,
                ),
                Container(
                  width: MediaQuery.of(context).size.width - 230,
                  height: 1,
                  color: Colors.black12,
                ),
                SizedBox(
                  height: 25,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          alignment: Alignment.centerRight,
                          margin: EdgeInsets.only(right: 45),
                          child: const Text(
                            "Home Page",
                            style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.bold,
                              fontSize: 22,
                              fontFamily: 'inter',
                            ),
                          ),
                        ),
                        Container(
                            margin: EdgeInsets.only(left: 200),
                            child: Divider(
                              height: 15,
                              thickness: 4,
                            )),
                        Row(
                          children: [
                            Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.white,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.grey.withOpacity(0.5),
                                      spreadRadius: 5,
                                      blurRadius: 7,
                                      offset: Offset(
                                          0, 3), // changes position of shadow
                                    ),
                                  ],
                                ),
                                margin: const EdgeInsets.only(
                                    top: 30, left: 12, right: 13, bottom: 10),
                                width: 300,
                                height:
                                    MediaQuery.of(context).size.height - 185,
                                alignment: Alignment.bottomRight,
                                padding: EdgeInsets.all(10),
                                child: Column(
                                  children: [
                                    SizedBox(
                                      height: 10,
                                    ),
                                    Container(
                                      padding:
                                          EdgeInsets.symmetric(horizontal: 20),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            "Admin Chat Section",
                                            style: const TextStyle(
                                              color: Colors.black,
                                              fontWeight: FontWeight.bold,
                                              fontFamily: 'inter',
                                              fontSize: 16,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Divider(),
                                    Expanded(
                                      child: FutureBuilder<
                                          List<Map<String, dynamic>>>(
                                        future:
                                            AuthService.to.user?.fetchChats(),
                                        builder: (context, snapshot) {
                                          if (snapshot.connectionState ==
                                              ConnectionState.waiting) {
                                            return const Center(
                                              child: SpinKitFadingCircle(
                                                color: Colors.blueAccent,
                                                size: 30.0,
                                              ),
                                            );
                                          } else if (snapshot.hasError) {
                                            return Center(
                                                child: Text(
                                                    'Error: ${snapshot.error}'));
                                          } else if (!snapshot.hasData ||
                                              snapshot.data!.isEmpty) {
                                            return const Center(
                                                child:
                                                    Text('No chats available'));
                                          } else {
                                            return ListView.builder(
                                              itemCount: snapshot.data!.length,
                                              reverse: true,
                                              itemBuilder: (context, index) {
                                                final chat =
                                                    snapshot.data![index];
                                                return ChatBubble(
                                                  message: chat['message'],
                                                  me: chat['isSelf'],
                                                );
                                              },
                                            );
                                          }
                                        },
                                      ),
                                    ),
                                    SizedBox(height: 16.0),
                                    Divider(),
                                    ChatInputField(
                                      usr: AuthService.to.user!,
                                      refreshChats: () {
                                        setState(() {});
                                      },
                                      isadmin: false,
                                    ),
                                  ],
                                )),
                            // Container(
                            //   margin: EdgeInsets.all(20.0),
                            //   padding: EdgeInsets.all(20.0),
                            //   decoration: BoxDecoration(
                            //     color: Colors.white,
                            //     borderRadius: BorderRadius.circular(10.0),
                            //     boxShadow: [
                            //       BoxShadow(
                            //         color: Colors.grey.withOpacity(0.5),
                            //         spreadRadius: 5,
                            //         blurRadius: 7,
                            //         offset: Offset(0, 3), // changes position of shadow
                            //       ),
                            //     ],
                            //   ),
                            //   child: Table(
                            //     border: TableBorder.all(color: Colors.black),
                            //     children: [
                            //       TableRow(
                            //         children: [
                            //           TableCell(
                            //             child: Padding(
                            //               padding: EdgeInsets.all(8.0),
                            //               child: Text('Cell 1'),
                            //             ),
                            //           ),
                            //           TableCell(
                            //             child: Padding(
                            //               padding: EdgeInsets.all(8.0),
                            //               child: Text('Cell 2'),
                            //             ),
                            //           ),
                            //           TableCell(
                            //             child: Padding(
                            //               padding: EdgeInsets.all(8.0),
                            //               child: Text('Cell 3'),
                            //             ),
                            //           ),
                            //         ],
                            //       ),
                            //       TableRow(
                            //         children: [
                            //           TableCell(
                            //             child: Padding(
                            //               padding: EdgeInsets.all(8.0),
                            //               child: Text('Cell 4'),
                            //             ),
                            //           ),
                            //           TableCell(
                            //             child: Padding(
                            //               padding: EdgeInsets.all(8.0),
                            //               child: Text('Cell 5'),
                            //             ),
                            //           ),
                            //           TableCell(
                            //             child: Padding(
                            //               padding: EdgeInsets.all(8.0),
                            //               child: Text('Cell 6'),
                            //             ),
                            //           ),
                            //         ],
                            //       ),
                            //       // Add more rows as needed
                            //     ],
                            //   ),
                            // ),
                          ],
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Container(
              width: 150,
              height: 150,
              margin: const EdgeInsets.only(left: 10, top: 10),
              child: Image.asset(
                'assets/logo.png',
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
