import 'dart:ui';
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import '../../Model/User.dart';
import '../../helper/auth_service.dart';
import '../../route.dart';
import '../Widgets/Appbar.dart';
import '../Widgets/chat_box.dart';

class DashBoard extends StatefulWidget {
  @override
  State<DashBoard> createState() => _DashBoardState();
}

class _DashBoardState extends State<DashBoard> {
  List<Users> csss = [];
  List<Users> allUsers = [];
  int showAll = 0;
  double chatwidth = 0;
  List<Users> chatuser = [];
  int totaluser = 0;
  int adminCount = 0;
  int foodDonorCount = 0;
  int recipientCount = 0;
  int volunteerCount = 0;
  @override
  void initState() {
    super.initState();
    getData();
  }

  void getData() async {
    csss = [];
    allUsers = [];
    adminCount = 0;
    foodDonorCount = 0;
    recipientCount = 0;
    volunteerCount = 0;

    QuerySnapshot<Map<String, dynamic>> userSnapshot =
        await FirebaseFirestore.instance.collection('Users').get();
    List<Users> users = userSnapshot.docs.map((doc) {
      return Users.fromJson(doc.data());
    }).toList();

    List<bool> hasUnseenMessages = List.filled(users.length, false);
    QuerySnapshot<Map<String, dynamic>> messageSnapshot =
        await FirebaseFirestore.instance.collection('ChatsAdmin').get();
    messageSnapshot.docs.forEach((doc) {
      String? userId = doc['userId'];
      bool? seen = doc['seen'];
      if (userId != null && seen != null) {
        int userIndex = users.indexWhere((user) => user.id == userId);
        if (userIndex != -1 && !seen) {
          hasUnseenMessages[userIndex] = true;
        }
      }
    });

    List<Users> sortedUsers = [];
    for (int i = 0; i < users.length; i++) {
      if (hasUnseenMessages[i]) {
        Users user = users[i].copyWith(seen: true);
        sortedUsers.insert(0, user);
      } else {
        sortedUsers.add(users[i]);
      }
    }

    setState(() {
      allUsers = sortedUsers;
      csss = sortedUsers;
      totaluser = users.length;
      adminCount = users.where((user) => user.type == 'Admin').length;
      foodDonorCount = users.where((user) => user.type == 'Food Donor').length;
      recipientCount = users.where((user) => user.type == 'Recipient').length;
      volunteerCount = users.where((user) => user.type == 'Volunteer').length;
    });
  }

  void filterUsers(String userType) {
    setState(() {
      if (userType == 'Admin') {
        csss = allUsers.where((user) => user.type == 'Admin').toList();
      } else if (userType == 'Food Donor') {
        csss = allUsers.where((user) => user.type == 'Food Donor').toList();
      } else if (userType == 'Recipient') {
        csss = allUsers.where((user) => user.type == 'Recipient').toList();
      } else if (userType == 'Volunteer') {
        csss = allUsers.where((user) => user.type == 'Volunteer').toList();
      } else if (userType == 'Status') {
        csss = allUsers.where((user) => !user.sts).toList();
      } else if (userType == 'Chat') {
        csss = allUsers.where((user) => user.seen ?? false).toList();
      } else {
        csss = allUsers;
      }
    });
  }

  void _addtochatuser(Users usr) {
    setState(() {
      chatuser.add(usr);
    });
  }

  void _removefromchatuser(Users usr) {
    getData();
    setState(() {
      chatuser.remove(usr);
    });
  }

  Future<void> markMessagesAsSeen(String userId) async {
    QuerySnapshot<Map<String, dynamic>> snapshot = await FirebaseFirestore
        .instance
        .collection('ChatsAdmin')
        .where('userId', isEqualTo: userId)
        .where('seen', isEqualTo: false)
        .get();
    WriteBatch batch = FirebaseFirestore.instance.batch();
    snapshot.docs.forEach((doc) {
      batch.update(doc.reference, {'seen': true});
    });
    await batch.commit();
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/bg.png"), fit: BoxFit.fill)),
        child: Stack(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Appbarr(ishome: true,),
                Container(
                  color: Colors.white,
                  height: 10,
                ),
                Container(
                  width: MediaQuery.of(context).size.width - 230,
                  height: 1,
                  color: Colors.black12,
                ),
                SizedBox(
                  height: 25,
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          alignment: Alignment.centerRight,
                          margin: EdgeInsets.only(right: 45),
                          child: const Text(
                            "Dashboard",
                            style: TextStyle(
                              color: Colors.black87,
                              fontWeight: FontWeight.bold,
                              fontSize: 22,
                              fontFamily: 'inter',
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(horizontal: 45),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap: () {
                                  filterUsers("All");
                                },
                                child: Container(
                                  width: 200,
                                  decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                          color: ((Colors.grey[300])!),
                                          blurRadius: 4,
                                          offset:
                                              Offset(4, 8), // Shadow position
                                        ),
                                      ],
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(5)),
                                  //margin: EdgeInsets.all(10),
                                  margin: const EdgeInsets.only(
                                      left: 0, top: 10, right: 10, bottom: 10),
                                  padding: EdgeInsets.all(30),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        "Users",
                                        style: TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 16,
                                            color: Colors.black),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        "$totaluser",
                                        style: const TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black),
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      Image.asset(
                                        "assets/icons/icon_up.png",
                                        width: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              InkWell(
                                onTap: () {
                                  filterUsers("Admin");
                                },
                                child: Container(
                                  width: 200,
                                  decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                          color: ((Colors.grey[300])!),
                                          blurRadius: 4,
                                          offset:
                                              Offset(4, 8), // Shadow position
                                        ),
                                      ],
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(5)),
                                  //margin: EdgeInsets.all(10),
                                  margin: EdgeInsets.only(
                                      left: 0, top: 10, right: 10, bottom: 10),
                                  padding: EdgeInsets.all(30),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Admin",
                                        style: TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 16,
                                            color: Colors.black),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        "${adminCount}",
                                        style: const TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black),
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      Image.asset(
                                        "assets/icons/icon_up.png",
                                        width: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              InkWell(
                                onTap: () {
                                  filterUsers("Food Donor");
                                },
                                child: Container(
                                  width: 200,
                                  decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                          color: ((Colors.grey[300])!),
                                          blurRadius: 4,
                                          offset:
                                              Offset(4, 8), // Shadow position
                                        ),
                                      ],
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(5)),
                                  margin: EdgeInsets.all(10),
                                  padding: EdgeInsets.all(30),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Food Donors",
                                        style: TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 16,
                                            color: Colors.black),
                                      ),
                                      SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        "${foodDonorCount}",
                                        style: const TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black),
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Image.asset(
                                        "assets/icons/icon_down.png",
                                        width: 20,
                                      ),

                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              InkWell(
                                onTap: () {
                                  filterUsers("Recipient");
                                },
                                child: Container(
                                  width: 200,
                                  decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                          color: ((Colors.grey[300])!),
                                          blurRadius: 4,
                                          offset:
                                              Offset(4, 8), // Shadow position
                                        ),
                                      ],
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(5)),
                                  margin: EdgeInsets.all(10),
                                  padding: EdgeInsets.all(30),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        "Recipients",
                                        style: TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 16,
                                            color: Colors.black),
                                      ),
                                      SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        "${recipientCount}",
                                        style: const TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black),
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      Image.asset(
                                        "assets/icons/icon_up.png",
                                        width: 20,
                                      ),

                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              InkWell(
                                onTap: () {
                                  filterUsers("Volunteer");
                                },
                                child: Container(
                                  width: 200,
                                  decoration: BoxDecoration(
                                      boxShadow: [
                                        BoxShadow(
                                          color: ((Colors.grey[300])!),
                                          blurRadius: 4,
                                          offset:
                                              Offset(4, 8), // Shadow position
                                        ),
                                      ],
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(5)),
                                  margin: EdgeInsets.only(
                                      left: 10, top: 10, right: 0, bottom: 10),
                                  padding: EdgeInsets.all(30),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        "Volunteers",
                                        style: TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 16,
                                            color: Colors.black),
                                      ),
                                      const SizedBox(
                                        height: 15,
                                      ),
                                      Text(
                                        "${volunteerCount}",
                                        style: const TextStyle(
                                            fontFamily: 'inter',
                                            fontSize: 24,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.black),
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      Image.asset(
                                        "assets/icons/icon_down.png",
                                        width: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: const EdgeInsets.only(
                            right: 45,
                            top: 20,
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              GestureDetector(
                                onTap: () {
                                  showAll = 0;
                                  filterUsers("ALL");
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: showAll == 0
                                        ? Colors.blue
                                        : Colors.transparent,
                                    borderRadius: const BorderRadius.horizontal(
                                      left: Radius.circular(20),
                                    ),
                                    border: Border.all(
                                      color: Colors.blue,
                                      width: 1,
                                    ),
                                  ),
                                  child: Text(
                                    'Show All',
                                    style: TextStyle(
                                      fontFamily: 'inter',
                                      color: showAll == 0
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  showAll = 1;
                                  filterUsers("Chat");
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: showAll == 1
                                        ? Colors.blue
                                        : Colors.transparent,
                                    border: const Border.symmetric(
                                      horizontal: BorderSide(
                                        color: Colors.blue,
                                        width: 1,
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Unseen Chat',
                                    style: TextStyle(
                                      fontFamily: 'inter',
                                      color: showAll == 1
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  showAll = 2;
                                  filterUsers("Admin");
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: showAll == 2
                                        ? Colors.blue
                                        : Colors.transparent,
                                    border: Border.all(
                                      color: Colors.blue,
                                      width: 1,
                                    ),
                                  ),
                                  child: Text(
                                    'Admin',
                                    style: TextStyle(
                                      fontFamily: 'inter',
                                      color: showAll == 2
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  showAll = 3;
                                  filterUsers("Recipient");
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: showAll == 3
                                        ? Colors.blue
                                        : Colors.transparent,
                                    border: Border.all(
                                      color: Colors.blue,
                                      width: 1,
                                    ),
                                  ),
                                  child: Text(
                                    'Recipient',
                                    style: TextStyle(
                                      fontFamily: 'inter',
                                      color: showAll == 3
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  showAll = 4;
                                  filterUsers("Food Donor");
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: showAll == 4
                                        ? Colors.blue
                                        : Colors.transparent,
                                    border: const Border.symmetric(
                                      horizontal: BorderSide(
                                        color: Colors.blue,
                                        width: 1,
                                      ),
                                    ),
                                  ),
                                  child: Text(
                                    'Food Donor',
                                    style: TextStyle(
                                      fontFamily: 'inter',
                                      color: showAll == 4
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  showAll = 5;
                                  filterUsers("Volunteer");
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 10, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: showAll == 5
                                        ? Colors.blue
                                        : Colors.transparent,
                                    borderRadius: const BorderRadius.horizontal(
                                      right: Radius.circular(20),
                                    ),
                                    border: Border.all(
                                      color: Colors.blue,
                                      width: 1,
                                    ),
                                  ),
                                  child: Text(
                                    'Volunteer',
                                    style: TextStyle(
                                      fontFamily: 'inter',
                                      color: showAll == 5
                                          ? Colors.white
                                          : Colors.black,
                                      fontSize: 12,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          width: 1150,
                          decoration: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                  color: ((Colors.grey[300])!),
                                  blurRadius: 4,
                                  offset: const Offset(4, 8), // Shadow position
                                ),
                              ],
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(5)),
                          margin: const EdgeInsets.only(
                              left: 310, right: 15, top: 10, bottom: 20),
                          padding: const EdgeInsets.symmetric(
                              vertical: 30, horizontal: 10),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                padding: const EdgeInsets.only(bottom: 10),
                                child: Row(
                                  children: [
                                    Expanded(
                                      flex: 1,
                                      child: Container(
                                        margin: EdgeInsets.only(
                                            left: 30, right: 10),
                                        child: const Text(
                                          "SL",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                              fontFamily: 'inter'),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 3,
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: const Text(
                                          "Name",
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                              fontFamily: 'inter'),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 3,
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: const Text(
                                          "Email",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                              fontFamily: 'inter'),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 3,
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: const Text(
                                          "Phone",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                              fontFamily: 'inter'),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 4,
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: const Text(
                                          "Address",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                              fontFamily: 'inter'),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: const Text(
                                          "Type",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                              fontFamily: 'inter'),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 1,
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: const Text(
                                          "Chat",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                              fontFamily: 'inter'),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      flex: 2,
                                      child: Container(
                                        margin: const EdgeInsets.only(
                                            left: 10, right: 10),
                                        child: const Text(
                                          "Action",
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                              fontFamily: 'inter'),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                width: double.infinity,
                                height: 1,
                                color: Colors.black12,
                              ),
                              csss.isEmpty
                                  ? Container(
                                      alignment: Alignment.center,
                                      margin: EdgeInsets.only(top: 10),
                                      child: const Text(
                                        'No Users Found.',
                                        style: TextStyle(
                                            fontFamily: 'inter', fontSize: 18),
                                      ),
                                    )
                                  : MediaQuery.removePadding(
                                      context: context,
                                      removeTop: true,
                                      child: ListView.builder(
                                        shrinkWrap: true,
                                        physics:
                                            const NeverScrollableScrollPhysics(),
                                        itemCount: csss.length,
                                        itemBuilder: (context, index) {
                                          return Container(
                                            padding: const EdgeInsets.only(
                                                bottom: 5),
                                            margin:
                                                const EdgeInsets.only(top: 15),
                                            child: Column(
                                              children: [
                                                Container(
                                                  height: 20,
                                                  child: Row(
                                                    children: [
                                                      Expanded(
                                                        flex: 1,
                                                        child: Container(
                                                          margin:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 30,
                                                                  right: 10),
                                                          child: Text(
                                                            (index + 1)
                                                                .toString(),
                                                            textAlign: TextAlign
                                                                .center,
                                                            style:
                                                                const TextStyle(
                                                                    fontSize:
                                                                        14,
                                                                    color: Colors
                                                                        .black,
                                                                    fontFamily:
                                                                        'inter'),
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: 3,
                                                        child: Container(
                                                          margin:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 10,
                                                                  right: 10),
                                                          child: Text(
                                                            csss[index].name,
                                                            style:
                                                                const TextStyle(
                                                                    fontSize:
                                                                        14,
                                                                    color: Colors
                                                                        .black,
                                                                    fontFamily:
                                                                        'inter'),
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: 3,
                                                        child: Container(
                                                          margin:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 10,
                                                                  right: 10),
                                                          child: Text(
                                                            csss[index].email,
                                                            textAlign: TextAlign
                                                                .center,
                                                            style: TextStyle(
                                                                fontSize: 14,
                                                                color: Colors
                                                                    .black,
                                                                fontFamily:
                                                                    'inter'),
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: 3,
                                                        child: Container(
                                                          margin:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 10,
                                                                  right: 10),
                                                          child: Text(
                                                            csss[index].phone,
                                                            textAlign: TextAlign
                                                                .center,
                                                            style:
                                                                const TextStyle(
                                                                    fontSize:
                                                                        14,
                                                                    color: Colors
                                                                        .black,
                                                                    fontFamily:
                                                                        'inter'),
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: 4,
                                                        child: Container(
                                                          margin:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 10,
                                                                  right: 10),
                                                          child: Text(
                                                            csss[index].address,
                                                            textAlign: TextAlign
                                                                .center,
                                                            style:
                                                                const TextStyle(
                                                                    fontSize:
                                                                        14,
                                                                    color: Colors
                                                                        .black,
                                                                    fontFamily:
                                                                        'inter'),
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: 2,
                                                        child: Container(
                                                          margin:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 10,
                                                                  right: 10),
                                                          child: Text(
                                                            csss[index].type,
                                                            textAlign: TextAlign
                                                                .center,
                                                            style:
                                                                const TextStyle(
                                                                    fontSize:
                                                                        14,
                                                                    color: Colors
                                                                        .black,
                                                                    fontFamily:
                                                                        'inter'),
                                                          ),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: 1,
                                                        child: Container(
                                                          margin:
                                                              const EdgeInsets
                                                                  .only(
                                                                  left: 10,
                                                                  right: 10),
                                                          child: !(csss[index]
                                                                      .id ==
                                                                  AuthService.to
                                                                      .user?.id)
                                                              ? csss[index].sts
                                                                  ? InkWell(
                                                                      onTap:
                                                                          () {
                                                                        _addtochatuser(
                                                                            csss[index]);
                                                                      },
                                                                      child:
                                                                          FittedBox(
                                                                        child:
                                                                            Stack(
                                                                          children: [
                                                                            Container(
                                                                              width: 22,
                                                                              padding: const EdgeInsets.all(4.0),
                                                                              decoration: BoxDecoration(color: Colors.blueAccent, borderRadius: BorderRadius.circular(100)),
                                                                              child: const Icon(
                                                                                Icons.chat_outlined,
                                                                                size: 13,
                                                                                color: Colors.white,
                                                                              ),
                                                                            ),
                                                                            if (csss[index].seen ??
                                                                                false || showAll == 1)
                                                                              Positioned(
                                                                                top: 0,
                                                                                right: 0,
                                                                                child: Container(
                                                                                  width: 8,
                                                                                  height: 8,
                                                                                  decoration: const BoxDecoration(
                                                                                    shape: BoxShape.circle,
                                                                                    color: Colors.red,
                                                                                  ),
                                                                                ),
                                                                              ),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    )
                                                                  : FittedBox(
                                                                      child: Container(
                                                                          width: 22,
                                                                          padding: const EdgeInsets.all(4.0),
                                                                          decoration: BoxDecoration(color: Colors.blueAccent, borderRadius: BorderRadius.circular(100)),
                                                                          child: const Icon(
                                                                            Icons.chat_outlined,
                                                                            size:
                                                                                13,
                                                                            color:
                                                                                Colors.white,
                                                                          )),
                                                                    )
                                                              : SizedBox(),
                                                        ),
                                                      ),
                                                      Expanded(
                                                        flex: 2,
                                                        child: Container(
                                                            margin:
                                                                const EdgeInsets
                                                                    .only(
                                                                    left: 10,
                                                                    right: 10),
                                                            child:
                                                                csss[index].sts
                                                                    ? InkWell(
                                                                        onTap:
                                                                            () async {
                                                                          Get.dialog(
                                                                            Dialog(
                                                                              shape: RoundedRectangleBorder(
                                                                                borderRadius: BorderRadius.circular(10.0),
                                                                              ),
                                                                              child: Container(
                                                                                width: 400,
                                                                                padding: EdgeInsets.all(20.0),
                                                                                child: Column(
                                                                                  mainAxisSize: MainAxisSize.min,
                                                                                  children: [
                                                                                    const Text(
                                                                                      'Delete User',
                                                                                      style: TextStyle(
                                                                                        fontSize: 20,
                                                                                        fontWeight: FontWeight.bold,
                                                                                      ),
                                                                                    ),
                                                                                    SizedBox(height: 10),
                                                                                    Text(
                                                                                      "Are you sure to delete '${csss[index].name}' from the list",
                                                                                      style: TextStyle(fontSize: 16),
                                                                                    ),
                                                                                    SizedBox(height: 20),
                                                                                    Row(
                                                                                      mainAxisAlignment: MainAxisAlignment.center,
                                                                                      children: [
                                                                                        ElevatedButton(
                                                                                          onPressed: () {
                                                                                            Get.back();
                                                                                          },
                                                                                          style: ElevatedButton.styleFrom(
                                                                                            backgroundColor: Colors.grey,
                                                                                          ),
                                                                                          child: const Text(
                                                                                            'Cancel',
                                                                                            style: TextStyle(color: Colors.white, fontFamily: 'inter', fontSize: 18),
                                                                                          ),
                                                                                        ),
                                                                                        SizedBox(width: 20),
                                                                                        ElevatedButton(
                                                                                          onPressed: () {
                                                                                            FirebaseFirestore.instance.collection('Users').doc(csss[index].id).update({
                                                                                              "Status": false,
                                                                                            });
                                                                                            Get.back();
                                                                                          },
                                                                                          style: ElevatedButton.styleFrom(
                                                                                            backgroundColor: Colors.blue,
                                                                                          ),
                                                                                          child: Text(
                                                                                            'Disable',
                                                                                            style: TextStyle(color: Colors.white, fontFamily: 'inter', fontSize: 18),
                                                                                          ),
                                                                                        ),
                                                                                        SizedBox(width: 20),
                                                                                        ElevatedButton(
                                                                                          onPressed: () {
                                                                                            FirebaseFirestore.instance.collection('Users').doc(csss[index].id).delete().then((value) {
                                                                                              getData();
                                                                                            });
                                                                                            Get.back();
                                                                                          },
                                                                                          style: ElevatedButton.styleFrom(
                                                                                            backgroundColor: Colors.red,
                                                                                          ),
                                                                                          child: Text(
                                                                                            'Delete',
                                                                                            style: TextStyle(color: Colors.white, fontFamily: 'inter', fontSize: 18),
                                                                                          ),
                                                                                        ),
                                                                                      ],
                                                                                    ),
                                                                                  ],
                                                                                ),
                                                                              ),
                                                                            ),
                                                                          );
                                                                        },
                                                                        child:
                                                                            FittedBox(
                                                                          child: Container(
                                                                              width: 22,
                                                                              padding: const EdgeInsets.all(4.0),
                                                                              decoration: BoxDecoration(color: Colors.blueAccent, borderRadius: BorderRadius.circular(100)),
                                                                              child: const Icon(
                                                                                Icons.more_vert_outlined,
                                                                                size: 13,
                                                                                color: Colors.white,
                                                                              )),
                                                                        ),
                                                                      )
                                                                    : Row(
                                                                        mainAxisAlignment:
                                                                            MainAxisAlignment.center,
                                                                        children: [
                                                                          InkWell(
                                                                            onTap:
                                                                                () async {
                                                                              FirebaseFirestore.instance.collection('Users').doc(csss[index].id).update({
                                                                                "Status": true,
                                                                              }).then((value) {
                                                                                getData();
                                                                              });
                                                                            },
                                                                            child: Container(
                                                                                padding: const EdgeInsets.all(4.0),
                                                                                decoration: BoxDecoration(color: Colors.blueAccent, borderRadius: BorderRadius.circular(100)),
                                                                                child: const Icon(
                                                                                  Icons.check,
                                                                                  size: 13,
                                                                                  color: Colors.white,
                                                                                )),
                                                                          ),
                                                                          SizedBox(
                                                                            width:
                                                                                3,
                                                                          ),
                                                                          InkWell(
                                                                            onTap:
                                                                                () {
                                                                              FirebaseFirestore.instance.collection('Users').doc(csss[index].id).delete().then((value) {
                                                                                getData();
                                                                              });
                                                                            },
                                                                            child: Container(
                                                                                padding: EdgeInsets.all(4.0),
                                                                                decoration: BoxDecoration(color: Colors.blueAccent, borderRadius: BorderRadius.circular(100)),
                                                                                child: const Icon(
                                                                                  Icons.close,
                                                                                  size: 13,
                                                                                  color: Colors.white,
                                                                                )),
                                                                          ),
                                                                        ],
                                                                      )),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 8,
                                                ),
                                                Container(
                                                  width: double.infinity,
                                                  height: 1,
                                                  color: Colors.black12,
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                      ),
                                    ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Positioned(
              bottom: 0,
              right: 0,
              width: MediaQuery.of(context).size.width > screenWidth
                  ? screenWidth
                  : MediaQuery.of(context).size.width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    height: chatuser.isEmpty ? 0 : 430,
                    margin: const EdgeInsets.only(right: 12),
                    child: Align(
                      alignment: Alignment.bottomRight,
                      child: ListView.builder(
                        itemCount: chatuser.length,
                        reverse: true,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (context, index) {
                          markMessagesAsSeen(chatuser[index].id);
                          return ChatBox(
                            removefrom: _removefromchatuser,
                            usr: chatuser[index],
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 150,
              height: 150,
              margin: const EdgeInsets.only(left: 10, top: 10),
              child: Image.asset(
                'assets/logo.png',
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
